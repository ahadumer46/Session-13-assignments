class Student:
    def __init__(self, first_name, last_name, district_code, enrolled_credits):
        self.first_name = first_name
        self.last_name = last_name
        self.district_code = district_code
        self.enrolled_credits = enrolled_credits

    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    def compute_tuition(self):
        if self.district_code == 'I':
            rate_per_credit = 250.00
        else:
            rate_per_credit = 500.00
        return self.enrolled_credits * rate_per_credit

# Testing the Student class
student1 = Student('Jane', 'Smith', 'I', 12)
student2 = Student('John', 'Doe', 'O', 15)

print(student1.full_name())          # Output: Jane Smith
print(student1.compute_tuition())    # Output: 3000.0 (12 credits at $250 each)
print(student2.full_name())          # Output: John Doe
print(student2.compute_tuition())    # Output: 7500.0 (15 credits at $500 each)
