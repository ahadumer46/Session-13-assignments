class Employee:
    def __init__(self, first, last, pay):
        self.first = first
        self.last = last
        self.pay = pay
        self.email = f"{first}.{last}@company.com"

    def full_name(self):
        return f"{self.first} {self.last}"

    def bonus(self, rate):
        return self.pay * rate

# Testing the Employee class
emp1 = Employee('John', 'Doe', 50000)
print(emp1.full_name())  # Output: John Doe
print(emp1.email)        # Output: John.Doe@company.com
print(emp1.bonus(0.1))   # Output: 5000.0 (10% bonus)
